from flask import Flask, render_template, request
import pandas as pd

app = Flask(__name__,template_folder="templates")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/calculate', methods=['POST'])
def calculate():
    df = pd.read_excel("vehicle.xlsx")
    
    distance = float(request.form['distance'])
    car_name = request.form['car_name']
    s_no = int(df.loc[df["Name"]==car_name, "S. no."].iloc[0])

    road = request.form['road']
    road1 = (df.loc[df["Name"]==car_name,road])
    road2 = float(road1[s_no])

    load = request.form['load']
    load1 = (df.loc[df["Name"]==car_name,load])
    load2 = float(load1[s_no])

    speed = request.form['speed']
    speed1 = df.loc[df["Name"]==car_name,speed]
    speed2 = float(speed1[s_no])

    temp = request.form['temp']
    temp1 = df.loc[df["Name"]==car_name,temp]
    temp2 = float(temp1[s_no])

    factor = road2 + load2 + speed2 + temp2
    factor = float(factor)

    carbon_emission = ((8887 * distance) / (21.6 * 1.6)) + ((8887 * distance) / (21.6 * 1.6)) * (factor / 100) / 4

    return render_template('result.html', carbon_emission=carbon_emission)

if __name__ == '__main__':
    app.run(debug=True)
