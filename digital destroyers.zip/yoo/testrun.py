import pandas as pd 
df = pd.read_excel("vehicle.xlsx")

distance=float(input("enter the distance in km: "))

car_name=input("Tell the name of car: ")
s_no = int(df.loc[df["Name"]==car_name,"S. no."].iloc[0])



print("Tell the road type")
print("1. Metalled")
print("2. Unmetalled")
print("3. Mud")
road=input("enter your choice: ")
road1=(df.loc[df["Name"]==car_name,road])
road2=float(road1[s_no])



print("Load")
print("1. from 0-200 kg")
print("2. from 200-500 kg")
print("3. from 500-1000 kg")
load=input("Enter the load: ")
load1=(df.loc[df["Name"]==car_name,load])
load2=float(load1[s_no])






print("The speed range are")
print("1. about 80 km/hr")
print("2. from 80-110 km/hr")
print("3. more than 110 km/hr")
speed=input("Enter your choice: ")
speed1=(df.loc[df["Name"]==car_name,speed])
speed2=float(speed1[s_no])


print("temp condition")
print("1. Cold")
print("2. Hot")
temp=input("enter the condition: ")
temp1=(df.loc[df["Name"]==car_name,temp])
temp2=float(temp1[s_no])


factor=road2+load2+speed2+temp2
factor=float(factor)


carbon_emmision=((8887*distance)/(21.6*1.6))+((8887*distance)/(21.6*1.6))*(factor/100)/4
print("carbon emmision is in grams of carbon")
print(carbon_emmision)